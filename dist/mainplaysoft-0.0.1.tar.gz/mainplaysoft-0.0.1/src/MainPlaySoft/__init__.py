"""
\u0420\u0430\u0437\u0440\u0430\u0431\u043E\u0442\u0447\u0438\u043A: MainPlay TG
https://t.me/MainPlayCh"""

__scripts__ = []
__all__ = []
from ._module_info import version as __version__
from .core import MPSoft
__all__.sort()
