name = "MainPlaySoft"
version = "0.0.1"
